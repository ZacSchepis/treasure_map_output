const rp = require("request-promise");
const fs = require('fs')
async function scrape_pirates(link){
    return await rp(link).then(function(html){return html})
        // function(html){
        //     // console.log(html)
        //     // let t =  html
        //     // console.log(html)
            
        // }

    
}

async function fuck_it(){
    var t = {}
    for(let i=0;i<=199;i++){
        let link = `http://treasure.chal.pwni.ng/${i}.js.map`
        console.log(link)
        // let res = await scrape_pirates(link)
        res = await scrape_pirates(link)
        console.log(res)
        // fs.writeFileSync(`./data/maps/num${i}.txt`,String(res))

        // fs.writeFileSync(`./data/meta/${i}.txt`,String(res))
        fs.appendFile(`./data/java_scripts/${i}.js`,String(`\nconst map_crap = ${res}`),(err)=>{console.err})

    }
    console.log(t)
    
}
async function b_go(bar){
    var temp = {}
    const b_temp = bar.split("\n")
    b_temp.forEach(element => {
        temp[element] =  go(element)
    });
    console.log(temp)
    // go("a")
}
async function go(letter,bti,moi,tg,fl){
    const upc = letter
    return eval(Strign(fl))
}
async function begin_the_crap(){
    let fileName = ''; let fileDir ='./data/'; let fileSubDir = '';
    for(let foo=0;foo<=199;foo++){
        fileName = `${foo}`
        var temp = {}
        let tempContents = fs.readFileSync(`${fileDir}java_scripts/${fileName}.js`,`utf-8`)
        let metaData = fs.readFileSync(`${fileDir}meta/${fileName}.txt`,'utf-8')
        let tStrip = tempContents.split("\n")
        const b64 = tStrip.slice(1,66).join("\n").replace(";","")
        const bti = b64.trim().split("\n").reduce((acc, x, i) => (acc.set(x, i), acc), new Map());
        const tg = JSON.parse(tStrip[75].split(" = ")[1])
        const fl = tStrip[71].split(" = ")[1]
        const moi = metaData
        const b_temp = b64.split("\n")
        b_temp.forEach(element => {
            let upc = element
            let res = eval(fl)
            // if(res==='success.js'){
            //     console.log(temp[element])
            // }
            temp[element] =  res
        });
        fs.appendFileSync('./data/result.txt',String(JSON.stringify(temp)),(err)=>{console.err})
    // console.log(temp)

    }



    // let file_name = `0`
    // let file_dir = './data/'
    // let file_sub_dir = 'java_scripts/'
    // let temp_contents = fs.readFileSync(`${file_dir}java_scripts/${file_name}.js`,'utf-8')
    // let meta_data_ = fs.readFileSync(`${file_dir}meta/${file_name}.txt`,'utf-8')
    // let t_strip = temp_contents.split("\n")
    
    // const b64 = t_strip.slice(1,66).join("\n").replace(";","")
    // const upc = 'a'
    // const moi = meta_data_
    // const bti = 
    
    // // const fl    
    //  console.log(eval(fl))



}
begin_the_crap()








// console.log(tg)

// console.log(t_strip.slice(0,66))

// fuck_it()

// await rp().then(
//     function(html)
//     {
//         // result.title = html.split(titlepat)[1];result.url=html.split(numpat)[1];result.picture=html.split(pat)[1]}).catch(function(err){console.log(err)
//         return html
//     }
//     )

// async function ScrapeXKCD(){
//     const xkcdlink = "https://c.xkcd.com/random/comic/";
//     const sta = Date.now();
//     let result={}
//     const pat =/<meta property="og:image" content="([^<]*)">/
//     const numpat = /<meta property="og:url" content="([^<]*)">/
//     const titlepat = /<meta property="og:title" content="([^<]*)">/
//     await rp(xkcdlink).then(function(html){result.title = html.split(titlepat)[1];result.url=html.split(numpat)[1];result.picture=html.split(pat)[1]}).catch(function(err){console.log(err)})
//     result.time = Date.now()-sta;
//     return result
// }